<?php
if(isset($_POST['op'])){
	$op = $_POST["op"];
}else{
	$op = "Select Feature";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Customer Dashboard</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body style = "background-color:white">

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Product Recommendations</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu message-dropdown">
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading">
                                            <strong> Lakshmi </strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>The Iphone Speaker Quality is too Bad</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading">
                                            <strong>Gowri</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 12:12 PM</p>
                                        <p> The samsung screen is having too many scratches</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading">
                                            <strong> Harsha </strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 09:45 AM</p>
                                        <p>Nikon's Image Photo Quality is Amazing!!!!</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-footer">
                            <a href="#">Read All New Messages</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.html"><i class="fa fa-fw fa-dashboard"></i> Customer Dashboard</a>
                    </li>
                    <li>
                        <a href="index.html"><i class="fa fa-fw fa-bar-chart-o"></i>Phone Recommendations</a>
                    </li>
                    <li>
                        <a href="index.html"><i class="fa fa-fw fa-bar-chart-o"></i>Camera Recommendations</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Customer Dashboard
                            <small></small>
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-file"></i> Blank Page
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->
			<?php
			$servername = "localhost";
			$username = "root";
			$password = "";

			// Create connection
			$conn = mysql_connect($servername, $username, $password);
			mysql_select_db("review") or die(mysql_error());
			// Check connection
			if (!$conn) {
			die("Connection failed: " . mysql_connect_error());
			}
			//echo "Connected successfully";
?>
			<div class="main_content">

			<div class="sd_left">

			<div class="text_padding">
			<h2>Select a Feature</h2>
			<form method="post" action="#">
			<p>
			<select name="op">
			<option value="1">Select feature</option>
			<option value="2" <?php if($op == "2") echo "selected"; ?>>screen</option>
			<option value="3" <?php if($op == "3") echo "selected"; ?>>battery</option>
			<option value="4" <?php if($op == "4") echo "selected"; ?>>time</option>
			<option value="5" <?php if($op == "5") echo "selected"; ?>>price</option>
			<option value="6" <?php if($op == "6") echo "selected"; ?>>app</option>
			<option value="7" <?php if($op == "7") echo "selected"; ?>>camera</option>
			<option value="8" <?php if($op == "8") echo "selected"; ?>>quality</option>
			<option value="9" <?php if($op == "9") echo "selected"; ?>>card</option>
			<option value="10" <?php if($op == "10") echo "selected"; ?>>life</option>
			<option value="11" <?php if($op == "11") echo "selected"; ?>>service</option>
			<option value="12" <?php if($op == "12") echo "selected"; ?>>button</option>
			<option value="13" <?php if($op == "13") echo "selected"; ?>>network</option>
			<option value="14" <?php if($op == "14") echo "selected"; ?>>software</option>
			<option value="15" <?php if($op == "15") echo "selected"; ?>>wifi</option>
			<option value="16" <?php if($op == "16") echo "selected"; ?>>keyboard</option>
			<option value="17" <?php if($op == "17") echo "selected"; ?>>music</option>
			<option value="18" <?php if($op == "18") echo "selected"; ?>>memory</option>
			<option value="19" <?php if($op == "19") echo "selected"; ?>>sim</option>
			<option value="20" <?php if($op == "20") echo "selected"; ?>>video</option>
			<option value="21" <?php if($op == "21") echo "selected"; ?>>power</option>
			<option value="22" <?php if($op == "22") echo "selected"; ?>>message</option>
			<option value="23" <?php if($op == "23") echo "selected"; ?>>size</option>
			<option value="24" <?php if($op == "24") echo "selected"; ?>>case</option>
			</select>
			<input type="submit" value="Go" class="submit" />
			</p>
			</form><br><br><p>
			<div>
			<table align=center width=95% class="disptable" >
			<tr bgcolor='lightgrey'>
			<th>PRODUCT TITLE</th><th>FEATURE</th><th>OPINION</th><th>SENTIMENT</th>
			<?php
			if(isset($_POST['op']))
			{
			if($_POST['op']==2)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='screen' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==3)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='battery' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==4)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='time' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==5)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='price' group by asin  order by final_value desc limit 10");
			elseif($_POST['op']==6)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='app' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==7)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='camera' group by asin  order by final_value desc limit 10");
			elseif($_POST['op']==8)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='quality' group by asin  order by final_value desc limit 10");
			elseif($_POST['op']==9)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='card' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==10)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='life' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==11)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='service' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==12)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='button' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==13)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='network' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==14)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='software' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==15)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='wifi' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==16)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='keyboard' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==17)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='music' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==18)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='memory' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==19)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='sim' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==20)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='video' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==21)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='power' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==22)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='message' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==23)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='size' group by asin order by final_value desc limit 10");
			elseif($_POST['op']==24)
			$extract = mysql_query("SELECT * FROM `recommend` where feature='case' group by asin order by final_value desc limit 10");
			else{
			echo "select the feature.";
			$extract =NULL;}
			if($extract != NULL){
			while($rows=mysql_fetch_assoc($extract)){
			echo "<tr><td><br><td><td></tr><tr>";
			echo "<td>".$rows['product_title']."<td>".$rows['feature']."<td>".$rows['opinion']."<td>".$rows['sentiment']."</tr>";
			}
			}
			}
			?>
</table>
</div>

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
