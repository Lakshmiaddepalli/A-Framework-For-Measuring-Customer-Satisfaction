# A-Framework-for-Measuring-Customer-Satisfaction-and-Product-Recommendation-for-Ecommerce (Final Year project)

+ Performed sentence level using Machine Learning algorithm,Logistic regression for Ecommerce product reviews and real time sentiment analysis on twitter data.
+ Performed aspect level Sentiment Analysis using lexicon based approach in Natural Language Processing that consisted of data preprocessor, semantic, sentiment, machine learning, recommender, and visualizer modules.
+ Built rule based NLP model of with negation handler with a Tkinter based GUI that dynamically analyses the customer review input using context dependencies.
+ Recommendation of products was done as feature based product recommendation and product based feature recommendation in the customer web portal.
+ Dynamic Data insights were provided according to granularity to various levels of manager in the manager web portal.
+ Performed Topic modelling using unsupervised clustering algorithm,Latent Dirichlet Allocation
+ The project tried to project how natural language processing and machine learning can help businesses develop useful insights and learn about latent KPIs.

Tools used- Python, nltk, Tkinter , Stanford NLP Parser, SentiWordNet Knime, Tableau, d3.js, cloudera hadoop(hdfs,hive, solr) 

Key Role - Research into the domain, end to end project architecture design and implementation, debugging, testing, documentation, presentation
