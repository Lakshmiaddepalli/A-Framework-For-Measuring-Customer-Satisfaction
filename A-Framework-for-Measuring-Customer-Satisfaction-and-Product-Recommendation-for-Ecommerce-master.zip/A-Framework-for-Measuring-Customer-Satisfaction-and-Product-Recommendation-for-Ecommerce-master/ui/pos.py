
# coding: utf-8

# In[10]:

from nltk.tokenize import RegexpTokenizer   
from nltk import pos_tag, stem

t = RegexpTokenizer(r'[\w\']+')
token = t.tokenize
stemmer = stem.RegexpStemmer('ing$|s$')
file = open('input.txt', "r")
pos = open('pt.txt',"w")
tags = []
input = file.readline()
while input:
    list_of_tokens = token(input)
    tags = pos_tag(list_of_tokens)
    pos.write(str(tags)+'\n')
    input = file.readline()
pos.close()
file.close()


# In[ ]:



